import paramiko
import socket

class SSHLogModel:
    def __init__(self, hostname, port, username, password, log_file_path):
        self.hostname = hostname
        self.port = port
        self.username = username
        self.password = password
        self.log_file_path = log_file_path
        self.ssh = None

    def validate_ip(self):
        try:
            socket.inet_aton(self.hostname)
            return True
        except socket.error:
            print("Error: Ingrese una dirección IP de servidor válida.")
            return False

    def establish_ssh_connection(self):
        if not self.validate_ip():
            return False

        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        try:
            ssh.connect(self.hostname, self.port, self.username, self.password)
            self.ssh = ssh
            return True
        except paramiko.AuthenticationException:
            error_message = "Error de autenticación SSH. Verifique la contraseña y/o usuario del servidor."
        except paramiko.SSHException as e:
            if "No hay métodos de autenticación disponibles" in str(e):
                error_message = "Error de autenticación SSH. Verifique el nombre de usuario del servidor."
            else:
                error_message = f"Error de conexión SSH: {str(e)}"
        except socket.gaierror:
            error_message = "Error: Ingrese la dirección válida del servidor."
        except socket.timeout:
            error_message = "Error: servidor sin conexion verifique su  internet"

        print(error_message)  # Opcional: Imprime el mensaje de error en la consola
        return False

    def copy_log_file(self):
        if not self.ssh:
            return False

        try:
            sftp = self.ssh.open_sftp()
            sftp.get(self.log_file_path, 'auth.log')
            print("Archivo de registro copiado exitosamente desde el servidor.")
            sftp.close()
            return True
        except FileNotFoundError:
            print("El archivo del servidor no fue encontrado.")
        except Exception as e:
            print("Error al copiar el archivo de registro:", str(e))
        return False

    def close_ssh_connection(self):
        if self.ssh:
            self.ssh.close()

