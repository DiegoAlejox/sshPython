import re
import time
from datetime import datetime
import tkinter as tk

class SSHLogController:
    def __init__(self, model, view):
        self.model = model
        self.view = view

    def run(self):
        try:
            if self.model.establish_ssh_connection():
                if self.model.copy_log_file():
                    self.model.close_ssh_connection()
                    self.parse_log_file()
        except Exception as e:
            # Manejar excepciones relacionadas con la conexión SSH o la copia del archivo de registro
            result_text = f"Error en la ejecución: {str(e)}"
            self.update_result_text(result_text)

    def parse_log_file(self):
        try:
            with open('auth.log', 'r') as log_file:
                log_lines = log_file.readlines()

            login_failure_pattern = re.compile(r'Failed password for .* from ([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)')

            failed_login_attempts = []
            last_failure_time = None
            failed_login_count = {}

            for line in log_lines:
                match = login_failure_pattern.search(line)
                if match:
                    ip = match.group(1)
                    current_time = time.time()

                    if last_failure_time:
                        time.sleep(1)

                    failed_login_attempts.append((ip, current_time))

                    last_failure_time = current_time

                    if ip in failed_login_count:
                        failed_login_count[ip] += 1
                    else:
                        failed_login_count[ip] = 1

                    if failed_login_count[ip] >= 3:
                        readable_time = datetime.fromtimestamp(last_failure_time).strftime('%Y-%m-%d %H:%M:%S')
                        result_text = f"¡Atención! Ataque de fuerza bruta desde esta IP: {ip}\n" \
                                      f"Hora del último intento fallido: {readable_time}\n" \
                                      f"Número total de intentos desde esta IP: {failed_login_count[ip]}"
                        self.update_result_text(result_text)
        except Exception as e:
            # Manejar excepciones relacionadas con la lectura del archivo de registro
            result_text = f"Error al leer el archivo de registro: {str(e)}"
            self.update_result_text(result_text)

    def update_result_text(self, text):
        self.view.result_text.delete(1.0, tk.END)
        self.view.result_text.insert(tk.END, text)


